# Corporate Design Manual v3.0
## Basis: `salvatore.html`, bereinigt

Referenzdokument für alle künftigen Seiten. Ziel: identische Handschrift, egal ob Portfolio, neudenken.io, Landingpage oder Tool-UI.

---

## 0. Cheat Sheet (die 10 Regeln, die den Look ausmachen)

1. **Warmes Papier statt Weiß.** Hintergrund ist niemals `#FFF`, sondern `hsl(41 23% 92%)`.
2. **Dreiklang der Schriften.** Fraunces (Serif) für alles Große, Geist (Sans) für Fließtext, JetBrains Mono für alles Kleine und Technische.
3. **Italic ist der Marker.** Jedes Highlight, jedes Akzentwort steht in kursiver Serif in Sienna. Das ist die Signatur.
4. **Negatives Letter-Spacing bei Groß, positives bei Klein.** Headlines ziehen zusammen (-0.04em), Mono-Labels ziehen auseinander (+0.15em).
5. **Serif-Headlines sind leicht, nicht fett.** Weight 300 bei großen Größen, 400 bis 500 erst ab ca. 30px abwärts.
6. **Mono-Labels sind immer UPPERCASE**, 9 bis 12px, gesperrt, in Sienna oder Grau.
7. **Kanten statt Schatten.** Struktur entsteht durch 1px-Tintenlinien und geteilte Grids, nicht durch Box-Shadows.
8. **Sienna ist der einzige echte Akzent.** Moos-Grün nur für Live-Status, Rost nur für Zweitakzent im Text.
9. **Zahlen sind Bilder.** Kennzahlen werden auf 54 bis 92px hochgezogen, in Serif-Light, Einheit als kursives Sienna-Suffix.
10. **Alles bewegt sich langsam.** `cubic-bezier(0.2, 0.8, 0.2, 1)`, 0.35s Standard, 1s bei Reveals.

---

## 1. Designphilosophie

Das System kombiniert drei Register, die normalerweise nicht zusammen auftreten:

| Register | Träger | Wirkung |
|---|---|---|
| **Editorial / Print** | Fraunces Light, Kursiv-Akzente, Kapitelnummern, Spaltensatz, Papierkorn | Seriosität, Denkarbeit, Buchcharakter |
| **Terminal / Engineering** | JetBrains Mono, Dark Console, Live-Logs, Status-Dots, `[TAG]`-Syntax | Technische Glaubwürdigkeit, Machermentalität |
| **Ambient / Weich** | Glasmorphismus, Blur-Blobs, Partikelfeld, Spotlight-Grid | Modernität, Ruhe, Tiefe |

Die Spannung dieser drei ist die Marke. Wer eine neue Seite baut, muss alle drei bedienen, sonst kippt es entweder ins Generische (nur Ambient) oder ins Trockene (nur Editorial).

**Metapher des Systems:** Ein warmes Blatt handgeschöpftes Papier, auf das mit Tinte gedruckt wurde, mit einem eingelassenen dunklen Terminal-Fenster.

---

## 2. Farbsystem

### 2.1 Token-Tabelle (autoritativ)

Alle Farben liegen als **HSL-Komponenten ohne `hsl()`-Wrapper** vor. Das ist Absicht: so lassen sich Alpha-Werte inline setzen mit `hsl(var(--token) / 40%)`.

| Token | HSL-Wert | Hex (exakt) | RGB | Rolle |
|---|---|---|---|---|
| `--bg-paper` | `41 23% 92%` | `#EFECE6` | 239, 236, 230 | Grundfläche, Seitenhintergrund |
| `--bg-panel` | `42 29% 87%` | `#E7E2D4` | 231, 226, 212 | Panels, Karten, Navbar (meist mit Alpha) |
| `--bg-inverse` | `30 13% 11%` | `#201C18` | 32, 28, 24 | Dark-Panels, Konsolen, Code |
| `--text-primary` | `30 8% 9%` | `#191715` | 25, 23, 21 | Headlines, Fettung, harte Rahmen |
| `--text-secondary` | `40 6% 27%` | `#494641` | 73, 70, 65 | Fließtext, Manifest-Text |
| `--text-muted` | `39 6% 38%` | `#67635B` | 103, 99, 91 | Labels, Quellenangaben, Footer |
| `--accent-primary` | `15 60% 40%` | `#A34729` | 163, 71, 41 | **Primärakzent Sienna/Kupfer** |
| `--accent-secondary` | `17 66% 29%` | `#7B3519` | 123, 53, 25 | Sekundärakzent Rost, Hover-States |
| `--accent-live` | `127 26% 33%` | `#3E6A43` | 62, 106, 67 | Live-Status, "Aktiv", Erfolg |
| `--accent-warn` | `28 62% 36%` | `#955823` | 149, 88, 35 | Warnung, Ocker (Reserve) |

Zusätzlich für `rgba()`-Tönungen:

| Token | Wert | Rolle |
|---|---|---|
| `--ink-rgb` | `25, 23, 21` | Basis aller Tinten-Tönungen (Hover, Gitternetz, Schatten) |
| `--accent-primary-rgb` | `163, 71, 41` | Textmarker, Spotlight, Partikel, Dot-Glow |
| `--accent-secondary-rgb` | `123, 53, 25` | Reserve |
| `--accent-live-rgb` | `62, 106, 67` | Status-Box-Fläche und -Rahmen |
| `--accent-warn-rgb` | `149, 88, 35` | Reserve |

> **Benennungslogik:** Tokens beschreiben die **Rolle**, nicht die Farbe. Wenn Sienna irgendwann Petrol wird, bleibt `--accent-primary` korrekt. Farbnamen in Token-Namen sind eine Zeitbombe.

### 2.2 Terminal-Kontext (eigene Textfarben)

Innerhalb dunkler Panels gelten abweichende Textfarben, weil die Ink-Tokens dort unlesbar wären:

| Token | Wert | Rolle |
|---|---|---|
| `--inverse-text-primary` | `#F2EEE5` | Haupttext im Dark Panel |
| `--inverse-text-secondary` | `#CBD5E1` | Standard-Logzeile |
| `--inverse-text-muted` | `#9A958C` | Systemzeile, gedämpft (5,7:1) |

Semantische Log-Farben (hartcodiert, Material-Palette):

| Klasse | Hex | Bedeutung |
|---|---|---|
| `.c-ok` | `#81C784` | Erfolg, OK-Meldung |
| `.c-accent` | `#FFB74D` | Metrik, Security |
| `.c-action` | `#64B5F6` | Sync, Aktion läuft |
| `.c-system` | `--inverse-text-muted` | Daemon, Systemrauschen |

### 2.3 Linien und Rahmen

| Token | Wert | Verwendung |
|---|---|---|
| `--border-hairline` | `30 8% 9% / 8%` | Standard-Trennlinie, 8 % Tinte |
| `--border-hairline-active` | `15 60% 40% / 35%` | Hover-Rahmen in Sienna |
| `--border-structural` | `30 8% 9% / 15%` | Footer-Trenner, Gitternetz-Zellen |

Zusätzlich im Einsatz:

- `1.5px solid hsl(var(--text-primary))` für "harte" Datentabellen-Oberkanten
- `2px solid hsl(var(--text-primary))` für Flaggschiff-Karten
- `1px dashed hsl(var(--accent-primary) / 20 bis 40%)` für Zitate, Badges, Meta-Kanten

**Die gestrichelte Linie ist ein bewusstes Stilmittel.** Sie markiert alles, was Beleg, Fußnote oder Quelle ist. Solide Linien markieren Struktur.

### 2.4 Farbregeln

- Sienna niemals flächig einsetzen. Es ist eine Linien-, Text- und Punktfarbe.
- Flächige Sienna-Anwendung maximal mit 2 bis 8 % Alpha als Tönung.
- Rost (`--accent-secondary`) nur für Hover-Zustände von Sienna-Links und für kursive Betonungen im Fließtext.
- Moos-Grün ausschließlich für Live-/Aktiv-Zustände. Nie dekorativ.
- Schwarz als reines `#000` kommt nicht vor. Dunkelster Ton ist `#191715`.
- Weiß als reines `#FFF` kommt nicht vor.

### 2.5 Kontrastwerte (WCAG, nach der Bereinigung)

| Kombination | gegen Papier | gegen Panel | Bewertung |
|---|---|---|---|
| `--text-primary` | 15,16:1 | 13,8:1 | AAA |
| `--text-secondary` | 7,97:1 | 7,26:1 | AAA |
| `--accent-secondary` (Rost) | 7,53:1 | 6,86:1 | AAA |
| `--accent-live` (Moos) | 5,32:1 | 4,85:1 | AA |
| `--accent-primary` (Sienna) | 5,10:1 | 4,65:1 | AA |
| `--text-muted` | 5,07:1 | 4,62:1 | AA |
| `--accent-warn` (Ocker) | 4,82:1 | 4,39:1 | AA auf Papier |

Alle Textfarben liegen jetzt über 4,5:1 gegen die Grundfläche. Die Anpassungen betrugen im Schnitt drei Prozentpunkte Helligkeit und sind im direkten Vergleich kaum wahrnehmbar.

**Regel für neue Seiten:** Mono-Labels nie unter 10px setzen. Bei 9px (Quellenzeile) ist zwar der Kontrast in Ordnung, die Lesbarkeit aber grenzwertig. Wo möglich auf 10 bis 11px gehen.

---

## 3. Typografie

### 3.1 Die drei Familien

```css
--font-sans:  'Geist', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
--font-serif: 'Fraunces', Georgia, serif;
--font-mono:  'JetBrains Mono', 'Fira Code', 'Courier New', monospace;
```

Google-Fonts-Ladezeile (Fraunces als Variable Font mit optischer Größenachse):

```html
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300..900;1,9..144,300..900&family=Geist:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
```

### 3.2 Rollenverteilung (streng einhalten)

| Familie | Zuständig für | Niemals für |
|---|---|---|
| **Fraunces** | H1 bis H4, Kennzahlen, Manifest-Absätze, Pull-Quotes, Logo, kursive Betonungen, Listenpunkte mit Rollencharakter | Fließtext unter 18px, Buttons, Labels |
| **Geist** | Fließtext 14 bis 16px, Beschreibungen, Karteninhalte | Headlines, Zahlen, Labels |
| **JetBrains Mono** | Eyebrows, Kapitelnummern, Labels, Tags, Badges, Statusanzeigen, Quellen, Footer, Konsole, Navigation | Fließtext, Headlines |

### 3.3 Typo-Skala (alle Werte aus dem Original)

**Display / Serif, Weight 300**

| Element | `font-size` | `line-height` | `letter-spacing` |
|---|---|---|---|
| Hero H1 | `clamp(52px, 7.5vw, 110px)` | `0.92` | `-0.04em` |
| Kontakt H2 | `clamp(52px, 8vw, 110px)` | `0.95` | `-0.04em` |
| Kennzahl (`.value`) | `clamp(54px, 7vw, 92px)` | `0.92` | `-0.04em` |
| Section-Title | `clamp(38px, 5.5vw, 76px)` | `0.98` | `-0.035em` |
| Rollen-Liste | `clamp(24px, 3.2vw, 36px)` | `1.25` | `-0.02em` |

**Sub-Display / Serif, Weight 400 bis 500**

| Element | `font-size` | `weight` | `line-height` | `letter-spacing` |
|---|---|---|---|---|
| Journey H3 | `clamp(26px, 3.2vw, 38px)` | 400 | `1.1` | `-0.025em` |
| Portfolio H4 | `clamp(22px, 2.4vw, 32px)` | 500 | `1.15` | `-0.02em` |
| Think H3 | `clamp(22px, 2.5vw, 30px)` | 500 | `1.15` | `-0.025em` |
| Abgrenzung H4 | `22px` | 400 | Standard | `-0.02em` |
| Badge-Wert | `17px` | 600 | Standard | Standard |

**Lead / Serif, Weight 300 (die "Manifest"-Ebene)**

| Element | `font-size` | `line-height` | `letter-spacing` |
|---|---|---|---|
| Hero-Manifest | `clamp(20px, 2.2vw, 26px)` | `1.4` | `-0.015em` |
| Daten-Intro | `clamp(20px, 2.4vw, 27px)` | `1.45` | `-0.01em` |
| These-Absatz | `clamp(20px, 2.3vw, 28px)` | `1.45` | `-0.015em` |
| Kontaktzeilen | `clamp(19px, 2.2vw, 24px)` | `1.6` | `-0.01em` |
| Plan-Absatz | `clamp(18px, 2.2vw, 22px)` | `1.5` | `-0.01em` |

**Body / Sans (Geist)**

| Kontext | `font-size` | `line-height` |
|---|---|---|
| Journey, Think-Evidence | `15.5px` | `1.65` bis `1.7` |
| Portfolio-Fließtext | `15px` | `1.6` |
| Daten-Beschreibung, Abgrenzung | `14.5px` | `1.55` bis `1.6` |
| Status-Box | `13px` | Standard |
| Global (`html`) | `16px` | `1.6` |

**Mono / Labels (alle UPPERCASE außer Konsole)**

| Element | `size` | `letter-spacing` |
|---|---|---|
| Hero-Eyebrow | `11px` | `0.25em` |
| Kontakt-Kicker | `11px` | `0.2em` |
| Plan-Überschrift H5 | `11px` | `0.18em` |
| Section-Num, Tags, Journey H4, Badge-Header | `10 bis 11px` | `0.15em` |
| These-Sidebar, Think-Nummer | `11 bis 12px` | `0.12em` |
| Nav-Status, Stack-Badge, Quelle, Footer, Zitat | `9 bis 11px` | `0.1em` |
| Nav-Link, Badge-Label, Company-Tag | `10 bis 12px` | `0.08em` |
| Konsole (nicht uppercase) | `11.5px` | `0`, `line-height: 1.8` |

### 3.4 Die Kursiv-Signatur (wichtigstes Einzelmerkmal)

In **jedem** Headline-Kontext existiert die Regel:

```css
.irgendeine-headline em {
  font-style: italic;
  font-weight: 400;            /* immer eine Stufe leichter als der Rest */
  color: hsl(var(--accent-primary));
}
```

Angewandt bei: `h1 em`, `.section-title em`, `.journey-side h3 em`, `.pf-card h4 em`, `.badge-val em`, `.logo-text em`, `.roles li em`, `.value .unit`, `.value .plus`.

**Regel für neue Seiten:** Pro Headline maximal ein kursiv gesetztes Wort oder eine Wortgruppe. Es ist eine Betonung, kein Muster.

### 3.5 Text-Auszeichnungen im Fließtext

| Klasse | Effekt | CSS |
|---|---|---|
| `strong` | Aufhellung auf Ink, Weight 600 | `color: hsl(var(--text-primary)); font-weight: 600;` |
| `em` (Body) | Wechsel in Fraunces kursiv, gleiche Größe | `font-family: var(--font-serif); font-style: italic;` |
| `.pull` | Pull-Quote in Rost, kursiv, 8 % größer | `color: hsl(var(--accent-secondary)); font-size: 1.08em;` |
| `.mark` | Textmarker-Effekt, unteres Drittel | `background: linear-gradient(180deg, transparent 65%, rgba(var(--accent-primary-rgb),0.15) 65%); padding: 0 4px;` |
| `.crossed` | Durchgestrichen in Sienna | `text-decoration: line-through; text-decoration-color: hsl(var(--accent-primary)); text-decoration-thickness: 2px; color: hsl(var(--text-muted));` |
| `.citation` | Gestricheltes Mono-Kästchen als Beleg | siehe Komponente 8.11 |

Der Wechsel von Sans zu kursiver Serif mitten im Fließtext ist Teil der Handschrift. Nicht wegoptimieren.

---

## 4. Raster und Layout

### 4.1 Container

```css
.container {
  max-width: 1240px;
  margin: 0 auto;
  padding: 0 24px;
  position: relative;
  z-index: 10;   /* über allen Hintergrund-Engines */
}
```

Mobile Override: einheitlich `var(--space-4)` (16px) ab ≤768px. Die früheren konkurrierenden Werte 12px und 14px aus zwei verschiedenen Blöcken sind zusammengeführt.

### 4.2 Vertikaler Rhythmus

| Ebene | Wert |
|---|---|
| `section.chapter` Padding | `120px 0`, mobil `80px 0` |
| Hero | `100px 0 80px` |
| Kontakt | `140px 0 100px` |
| Footer | `36px 0` |
| Abstand Section-Head zu Inhalt | `80px`, mobil `40 bis 50px` |

Jede Section endet mit `border-bottom: 1px solid hsl(var(--border-hairline))`. Das erzeugt den Kapitel-Charakter.

### 4.3 Grid-Verhältnisse (asymmetrisch, nie 50/50 bei Text)

| Layout | `grid-template-columns` | `gap` |
|---|---|---|
| Hero | `7fr 5fr` | `60px` |
| Section-Head | `220px 1fr` | `60px` |
| These | `3.5fr 8.5fr` | `60px` |
| Denkbeleg-Zeile | `80px 3.5fr 8.5fr` | `40px` |
| Plan | `1fr 1.2fr` | `60px` |
| Flagship-Karte | `5.5fr 6.5fr` | `40px` |
| Kennzahlen-Grid | `repeat(3, 1fr)` | `0` (geteilte Kanten) |
| Abgrenzung | `repeat(3, 1fr)` | `2px` (Gitternetz-Trick) |
| Portfolio | `repeat(2, 1fr)` | `24px` |
| Werdegang, Kontakt | `1fr 1fr` | `0` bzw. `80px` |

**Prinzip:** Asymmetrie bei Text (7/5, 3.5/8.5), Symmetrie nur bei Karten und Gegenüberstellungen.

### 4.4 Spacing-Werte im Einsatz

Nicht tokenisiert, aber konsistent verwendet:

`4, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32, 36, 40, 44, 48, 60, 80, 100, 120, 140`

Empfehlung: als 4px-Basisraster tokenisieren (siehe Abschnitt 14).

### 4.5 Border-Radius-Skala

| Wert | Verwendung |
|---|---|
| `4px` | Stack-Badges, Company-Tags, Zitat-Kästchen |
| `8px` | Status-Box, Terminal-Konsole |
| `12px` | Glass-Card, Portfolio-Karte |
| `16px` | Hero-Badge-Karte |
| `24px` | Navbar auf Mobile |
| `100px` | Navbar Desktop, Nav-Links (Pill) |
| `50%` | Status-Dots, Logo-Symbol |

**Regel:** Je kleiner das Element, desto kleiner der Radius. Pills nur für Navigation.

---

## 5. Hintergrund-Engines (die vier Schichten)

Reihenfolge und `z-index` sind Teil des Systems:

| z | Schicht | Zweck |
|---|---|---|
| `1` | `.antigravity-canvas` | Partikelfeld |
| `2` | `.glow-engine` | Zwei Blur-Blobs |
| `3` | `.grid-backdrop` | Technisches Gitternetz mit Maus-Maske |
| `10` | `.container` | Inhalt |
| `100` | `.header-wrap` | Sticky Navigation |
| `9999` | `body::before` | Papierkorn über allem |

### 5.1 Papierkorn (Kernstück der Wärme)

```css
body::before {
  content: '';
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 9999;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.05 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  mix-blend-mode: multiply;
  opacity: 0.75;
}
```

Parameter: `baseFrequency 0.85`, `numOctaves 3`, Alpha-Matrix `0.05`, `multiply` bei `0.75` Deckkraft. **Dieser Block gehört auf jede Seite.** Ohne ihn wirkt die Palette flach und billig.

### 5.2 Glow-Blobs

```css
.glow-blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(140px);
  opacity: 0.06;
  mix-blend-mode: multiply;
}
```

- Blob 1: `top: -10%; left: 15%; 50vw`, Sienna-Radialverlauf, `float-blob-1 30s infinite alternate ease-in-out`, Ziel `translate(8%, 12%) scale(1.15)`
- Blob 2: `bottom: -10%; right: 10%; 60vw`, Rost-Radialverlauf, `float-blob-2 35s infinite alternate ease-in-out`, Ziel `translate(-12%, -8%) scale(0.9)`

Auf hellem Grund muss `mix-blend-mode: multiply` gesetzt sein, sonst verschwinden die Blobs.

### 5.3 Gitternetz mit Spotlight-Maske

```css
.grid-backdrop {
  background-image:
    linear-gradient(rgba(var(--ink-rgb), 0.015) 1px, transparent 1px),
    linear-gradient(90deg, rgba(var(--ink-rgb), 0.015) 1px, transparent 1px);
  background-size: 50px 50px;
  mask-image: radial-gradient(circle 800px at var(--mouse-x, 50%) var(--mouse-y, 400px), black 30%, transparent 90%);
}
```

Rastermaß **50px**, Linienstärke 1px bei 1,5 % Deckkraft. Die Maus-Position wird per JS als `--mouse-x` / `--mouse-y` auf `documentElement` geschrieben, mit Interpolationsfaktor `0.12` pro Frame.

### 5.4 Partikelfeld

| Parameter | Wert |
|---|---|
| Dichte | `(canvas.width * canvas.height) / 18000` Partikel |
| Radius | `Math.random() * 2 + 0.8` px |
| Farbe | `rgba(176, 77, 44, opacity)` (Sienna) |
| Deckkraft | `0.25` bis `0.65`, bei Mausnähe bis `0.8` |
| Drift | `speedX ±0.1`, `speedY ±0.05`, mit Wrap-Around |
| Maus-Radius | `150px` |
| Abstoßung | `density = random * 30 + 12` |
| Rückkehr | `Delta / 20` pro Frame |
| Interpolation Zeiger | `0.12` pro Frame |

**Die Zeiger-Abstoßung ist auf Touch ausdrücklich gewollt und bleibt auf Mobilgeräten aktiv.** Sie ist der einzige interaktive Teil der Hintergrund-Ebenen und kostet praktisch nichts, weil die Partikelmenge flächenproportional berechnet wird: ca. 18 Partikel auf einem Telefon gegenüber 115 auf einem 1080p-Desktop.

Zwingende Bedingungen, damit sie korrekt arbeitet:

- Das Canvas ist `position: fixed` mit `canvas.width = window.innerWidth`. Es rechnet in **Viewport-Koordinaten**.
- `touches[0].clientX` ist bereits viewport-relativ. **Niemals `window.scrollX` addieren**, sonst wandert der Abstoßungspunkt beim Scrollen unter dem Finger weg.
- Genau ein Handler-Satz pro Event. Zwei Sätze auf `touchstart`/`touchmove` überschreiben sich gegenseitig.
- `touchend` und `touchcancel` setzen den Zeiger auf `null` zurück, damit die Partikel an ihre Ausgangsposition zurückfedern.

Optional, falls der Effekt auf dem Telefon zu wenig sichtbar ist: der Finger verdeckt den Bereich unter sich. Ein größerer Radius lässt die Abstoßung seitlich hervorschauen.

```js
mouse.radius = window.matchMedia('(pointer: coarse)').matches ? 190 : 150;
```

### 5.5 Textselektion

```css
::selection {
  background: rgba(var(--accent-primary-rgb), 0.15);
  color: hsl(var(--text-primary));
}
```

---

## 6. Glasmorphismus

```css
.glass-card {
  background: hsl(var(--bg-panel) / 65%);
  backdrop-filter: blur(20px) saturate(140%);
  border: 1px solid hsl(var(--border-hairline));
  border-radius: 12px;
  transition: var(--transition-smooth);
  overflow: hidden;
}
.glass-card:hover {
  transform: translateY(-2px);
  border-color: hsl(var(--border-hairline-active));
  box-shadow: 0 12px 30px rgba(var(--ink-rgb), 0.04);
}
```

**Spotlight-Overlay** über `::before`, folgt der Maus innerhalb der Karte:

```css
.glass-card::before {
  background: radial-gradient(800px circle at var(--card-mouse-x, 0px) var(--card-mouse-y, 0px), rgba(var(--accent-primary-rgb), 0.03), transparent 40%);
  opacity: 0;
  transition: opacity 0.5s ease;
}
.glass-card:hover::before { opacity: 1; }
```

Alpha-Werte für Panels im System:

| Kontext | Alpha auf `--bg-panel` |
|---|---|
| Navbar | `80%` |
| Hero-Badge | `75%` |
| Glass-Card | `65%` |
| Flagship-Karte | `60%` |
| Portfolio-Karte | `50%` |
| Werdegang linke Spalte | `40%` |

Blur-Werte: `20px` durchgehend, Sättigung `120%` (Navbar) bis `140%` (Karten).

---

## 7. Bewegung

```css
--transition-smooth: all 0.35s cubic-bezier(0.2, 0.8, 0.2, 1);
```

| Zweck | Dauer | Easing |
|---|---|---|
| Standard-Hover | `0.35s` | `cubic-bezier(0.2, 0.8, 0.2, 1)` |
| Spotlight-Fade | `0.5s` | `ease` |
| Scroll-Reveal | `1s` | `cubic-bezier(0.2, 0.8, 0.2, 1)` |
| Hero-Staffelung | `1s` mit `0.15s` / `0.3s` Verzögerung | dito |
| Status-Puls | `1.5s` bis `2s` infinite | `ease-in-out` |
| Blob-Drift | `30s` / `35s` infinite alternate | `ease-in-out` |
| Textwechsel These | `0.4s` opacity | `ease` |

Scroll-Reveal:

```css
.scroll-reveal { opacity: 0; transform: translateY(28px); }
.scroll-reveal.visible { opacity: 1; transform: translateY(0); }
```

IntersectionObserver mit `threshold: 0.08`, `rootMargin: '0px 0px -40px 0px'`, danach `unobserve`.

Puls-Keyframe (Status-Dots):

```css
@keyframes pulse-active {
  0%   { opacity: 0.3; transform: scale(0.9); }
  50%  { opacity: 1;   transform: scale(1.15); }
  100% { opacity: 0.3; transform: scale(0.9); }
}
```

**Bewegungsregel:** Nichts springt. Keine Bounce-Kurven, keine Rotationen, keine Scale-Sprünge über 1,15. Der einzige "harte" Hover-Effekt ist der Farbumschlag beim Company-Tag.

---

## 8. Komponentenbibliothek

### 8.1 Navbar (Pill)

- `position: sticky; top: 0; z-index: 100`, Wrapper-Padding `16px 0`, gescrollt `10px 0`
- `border-radius: 100px`, `padding: 12px 24px`
- Hintergrund `hsl(var(--bg-panel) / 80%)` plus `blur(20px) saturate(120%)`
- Dreiteilung: Logo links, Status mittig, Links rechts
- Logo-Symbol: `28x28px`, `border: 2px solid Sienna`, Kreis, Mono 700 bei 14px, Initiale
- Logo-Text: Fraunces 700, 19px, `-0.02em`, Suffix (`.io`) als kursives Sienna in Weight 500
- Nav-Link: Mono 12px, uppercase, `0.08em`, Pill-Padding `6px 12px`
- Nav-Link Hover: `background: rgba(var(--ink-rgb), 0.04)`
- CTA-Link (`.accented`): Sienna-Text plus `1px dashed hsl(var(--accent-primary) / 30%)`

### 8.2 Section-Head (Kapitelkopf)

Zweispaltig `220px 1fr`.

Linke Spalte:
```css
.section-num {
  font-family: var(--font-mono);
  font-size: 11px;
  letter-spacing: 0.15em;
  color: hsl(var(--accent-primary));
  padding-top: 14px;
  border-top: 2px solid hsl(var(--accent-primary));
  text-transform: uppercase;
}
.section-num strong {          /* Untertitel */
  display: block;
  font-family: var(--font-serif);
  font-style: italic;
  font-weight: 500;
  font-size: 14px;
  color: hsl(var(--text-secondary));
  text-transform: none;
  letter-spacing: 0;
}
```

Format des Inhalts: `01 — Evidenz` plus kursiver Untertitel. Die 2px-Sienna-Oberkante ist das visuelle Anker-Element jedes Kapitels.

### 8.3 Kennzahlen-Zelle

Aufbau von oben nach unten: Mono-Tag, Riesenzahl, Beschreibung, gestrichelte Quellenzeile.

- Zelle: `padding: 40px 32px`, Rahmen nur rechts und unten (Grid-Trick), Hintergrund `hsl(var(--bg-paper) / 50%)`, Hover auf `hsl(var(--bg-panel) / 45%)`
- Grid-Container: `border-top: 1.5px solid ink`, `border-left: 1px solid border-hairline`, `gap: 0`
- Tag: Mono 10px, uppercase, `0.15em`, Sienna, `margin-bottom: 24px`
- Wert: Fraunces 300, `clamp(54px, 7vw, 92px)`, `align-items: baseline`
- Einheit (`.unit`): `font-size: 0.35em`, Sienna, kursiv, Weight 400, `margin-left: 6px`
- Präfix (`.plus`): Sienna, kursiv, `margin-right: -4px`
- Beschreibung: 14,5px, `line-height: 1.55`, kursive Serif-Betonungen
- Quelle: Mono 9px, uppercase, `0.1em`, `--text-muted`, `border-top: 1px dashed`, `padding-top: 12px`

### 8.4 Hero-Badge-Karte

`padding: 32px`, `border-radius: 16px`, `box-shadow: 0 8px 32px rgba(var(--ink-rgb),0.02)`, Flex-Spalte mit `gap: 20px`.

- Header: Mono 10px, `0.15em`, Sienna, `border-bottom: 1px dashed`, `space-between` (rechts Versionsnummer)
- Zeile: Label (Mono 10px, `--text-muted`) über Wert (Fraunces 600, 17px)
- Status-Box: `rgba(green, 0.08)` Fläche, `rgba(green, 0.15)` Rahmen, `border-radius: 8px`, `padding: 12px 16px`, 7px-Puls-Dot

### 8.5 Terminal-Konsole

```css
.pf-flagship-console {
  background: hsl(var(--bg-inverse));
  border-radius: 8px;
  padding: 24px;
  font-family: var(--font-mono);
  font-size: 11.5px;
  line-height: 1.8;
  color: var(--inverse-text-secondary);
  border: 1px solid rgba(255, 255, 255, 0.05);
  height: 230px;
  overflow-y: auto;
  box-shadow: inset 0 2px 8px rgba(0,0,0,0.4);
}
```

Logzeilen-Konvention: `[DAEMON]`, `[SYS]`, `[SYNC]`, `[METRIC]`, `[OK]`, `[SEC]`, `[AUDIT]`. Neue Zeile alle **4000 ms**, Puffer maximal **12 Zeilen**, Auto-Scroll nach unten.

Der Inset-Shadow ist wichtig: er lässt das Panel wie ein eingelassenes Fenster im Papier wirken, nicht wie eine aufgesetzte Box.

### 8.6 Portfolio-Karte

- Basis: `padding: 36px 32px`, `border-radius: 12px`, `hsl(var(--bg-panel) / 50%)`
- Flaggschiff (`.span-12`): `border: 2px solid hsl(var(--text-primary))`, Fläche `60%`
- Kopfzeile (`.pf-head`): Mono 10px, Sienna, `space-between`, rechts Status-Badge
- Live-Badge: Moos-Grün plus 6px-Puls-Dot über `::before`
- Fuß (`.pf-stack`): `border-top: 1px solid border-hairline`, `padding-top: 20px`, Flex-Wrap `gap: 8px 12px`

### 8.7 Stack-Badge

```css
.stack-badge {
  font-family: var(--font-mono);
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: hsl(var(--text-muted));
  background: rgba(var(--ink-rgb), 0.03);
  padding: 4px 10px;
  border-radius: 4px;
}
.stack-badge.accented {
  color: hsl(var(--accent-primary));
  border: 1px dashed hsl(var(--accent-primary) / 20%);
  background: hsl(var(--accent-primary) / 2%);
}
```

### 8.8 Company-Tag (invertierender Hover)

```css
.company-tag {
  font-family: var(--font-mono);
  font-size: 11px;
  letter-spacing: 0.08em;
  padding: 8px 16px;
  background: hsl(var(--bg-paper));
  border: 1px solid hsl(var(--text-primary));
  border-radius: 4px;
}
.company-tag:hover {
  background: hsl(var(--text-primary));
  color: hsl(var(--bg-paper));
}
```

Einziger Vollton-Umschlag im System. Sparsam einsetzen.

### 8.9 Gegenüberstellung (Werdegang)

Zwei Spalten in einem Rahmen aus `1px solid ink`, Trennlinie `1.5px solid ink`, linke Spalte leicht getönt (`bg-card / 40%`), Padding `48px 40px`. Mobile: Trennlinie wandert von rechts nach unten.

Kopfzeile mit Mono-Label links und kursivem Serif-Pfeil rechts (`float: right`).

### 8.10 Gitter-Zellen (Abgrenzung)

Trick: Container bekommt `gap: 2px` und `background: hsl(var(--text-primary) / 15%)`, Zellen bekommen `background: hsl(var(--bg-paper))`. Der Hintergrund scheint als Gitternetz durch.

Kreuzzeichen: Fraunces kursiv 44px in Sienna als Präfix jeder Zelle.

### 8.11 Beleg-Zitat

```css
.citation {
  display: inline-block;
  font-family: var(--font-mono);
  font-size: 9.5px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: hsl(var(--accent-primary));
  padding: 3px 8px;
  border: 1px dashed hsl(var(--accent-primary) / 40%);
  border-radius: 4px;
  margin-left: 8px;
  vertical-align: 2px;
  background: hsl(var(--accent-primary) / 2%);
}
```

### 8.12 Denkbeleg-Zeile

Dreispaltig `80px 3.5fr 8.5fr`, `padding: 40px 0`, `border-top: 1px solid border-hairline`.

Hover-Effekt: `padding-left: 16px`. Die Zeile rückt beim Überfahren ein. Subtil, aber charakteristisch.

Untertitel innerhalb der H3 als `em` mit `display: block`, `font-size: 0.55em`, `--text-muted`, `letter-spacing: 0`.

### 8.13 Links

```css
.contact-lines a {
  display: inline-block;
  color: hsl(var(--accent-primary));
  text-decoration: none;
  border-bottom: 1.5px solid hsl(var(--accent-primary));
  padding-bottom: 2px;
}
.contact-lines a:hover {
  color: hsl(var(--accent-secondary));
  border-color: hsl(var(--accent-secondary));
}
```

Nie `text-decoration: underline`. Immer `border-bottom` mit 1,5px und 2px Abstand.

### 8.14 Footer

`border-top: 1px solid hsl(var(--text-primary) / 15%)`, `padding: 36px 0`, Mono 10,5px, uppercase, `0.1em`, `--text-muted`, `space-between` mit `flex-wrap`.

---

## 9. Responsive Verhalten

Drei Breakpoints, jeder nur einmal, in aufsteigender Spezifität sortiert.

| Breakpoint | Wesentliche Änderungen |
|---|---|
| **≤960px** | Hero einspaltig (`gap: 48px`), Section-Head einspaltig, Kennzahlen auf 2 Spalten, These einspaltig mit Sidebar als Chip-Reihe, Portfolio und Werdegang einspaltig, Kapitel-Padding auf `80px 0` |
| **≤768px** | Navbar wird zur Spalte mit `border-radius: 24px`, Nav-Links als scrollbare Reihe, Container-Padding `16px`, Portfolio und übrige Raster einspaltig, Konsole `10.5px` bei `200px` Höhe, dekorative Blur-Blobs abgeschaltet |
| **≤580px** | Kennzahlen einspaltig, Navbar-Padding `10px 16px`, Status-Anzeige ausgeblendet |
| **`prefers-reduced-motion`** | Alle Animationen und Transitions auf 0,01ms, Reveals sofort sichtbar, Partikel und Blobs aus, Hover-Verschiebungen aus |

Die Sidebar-Umwandlung bei These ist bemerkenswert: aus einer vertikalen Liste mit linker Randlinie wird eine horizontale Chip-Reihe.

**Wichtig beim Reduced-Motion-Block:** `.scroll-reveal` muss explizit auf `opacity: 1` gesetzt werden. Wird nur die Transition-Dauer auf 0 gesetzt, bleibt das Element bei `opacity: 0` hängen und die Seite ist leer.

---

## 10. Inhaltliche Tonalität (gehört zum CD)

Das Design trägt eine bestimmte Textsorte. Wer Layout kopiert, aber anders schreibt, bricht die Marke.

| Baustein | Muster |
|---|---|
| Kapitelnummerierung | `01 — Evidenz` mit kursivem Untertitel darunter |
| Headline | These oder Behauptung, ein kursives Sienna-Wort als Betonung, endet auf Punkt |
| Kennzahl | Zahl plus Einheit plus Erklärsatz plus **Quellenangabe** in Mono |
| Statusanzeige | Ein Wort, kleingeschrieben, plus pulsierender Punkt |
| Versionierung | `v2.8` sichtbar in der Badge-Karte |

Die Quellenzeile unter jeder Zahl ist das rhetorische Herz des Systems: es wird nie behauptet, ohne zu belegen. Dieses Muster auf jede neue Seite übertragen.

---

## 11. Basis für neue Seiten

Es gibt jetzt eine fertige Datei: **`design-system.css`**. Einbinden, fertig.

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300..900;1,9..144,300..900&family=Geist:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="design-system.css">
```

Enthalten sind: alle Tokens, Reset und Basis, Papierkorn, die drei Hintergrund-Ebenen, Typo-Hilfsklassen (`.t-display`, `.t-h2`, `.t-h3`, `.t-h4`, `.t-lead`, `.t-body`, `.t-label`), Auszeichnungen (`.pull`, `.mark`, `.crossed`, `.citation`, `.link`), Panels (`.glass-card`, `.console`), Navigation, Status-Elemente, Kapitel-Gerüst, Kennzahlen-Raster, Badges, Footer, Reveals, Breakpoints und der Reduced-Motion-Block.

Nicht enthalten (weil seitenspezifisch): Portfolio-Karten, Gegenüberstellungs-Raster, Denkbeleg-Zeilen, Abgrenzungs-Gitter. Diese stehen als Referenz in Abschnitt 8 und werden pro Seite kopiert.

### Minimal-Set für Zugehörigkeit zur Familie

1. `design-system.css` eingebunden
2. Papierkorn aktiv (kommt automatisch über `body::before`)
3. Container mit `max-width: 1240px`
4. Navbar-Pill mit Logo-Symbol und Status-Dot
5. Mindestens eine Fraunces-Headline mit **einem** kursiven Sienna-Wort
6. Mono-Labels in `0.15em` Sperrung
7. Gestrichelte Linien für alles Belegartige
8. Scroll-Reveal mit `28px` Versatz

### JS-Bausteine

Aus der bereinigten `salvatore.html` übernehmen:

```js
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const isCompact    = window.matchMedia('(max-width: 768px)').matches;
const motionOK     = !reduceMotion && !isCompact;

const ACCENT_RGB = getComputedStyle(document.documentElement)
  .getPropertyValue('--accent-primary-rgb').trim() || '163, 71, 41';
```

Jede Dauerbewegung (Partikel, Ticker, Konsolen-Loop) wird hinter `motionOK` gehängt, jeder Intervall zusätzlich über einen IntersectionObserver an die Sichtbarkeit gekoppelt.

---

## 12. Do's und Don'ts

**Do**

- Weiß und Schwarz durch die Papier- und Tinten-Tokens ersetzen
- Große Zahlen als gestalterisches Element nutzen
- Struktur über Linien erzeugen, nicht über Karten mit Schatten
- Kursive Serif als einziges Betonungsmittel im Fließtext
- Jede Behauptung mit einer Mono-Quellenzeile schließen
- Genau ein Live-Element pro Seite (Konsole, Puls-Dot oder Ticker)

**Don't**

- Keine zweite Akzentfarbe einführen. Das System hat bereits vier und nutzt effektiv zwei
- Keine großflächigen Sienna-Flächen
- Kein Fraunces unter 17px
- Kein JetBrains Mono im Fließtext
- Keine Border-Radien über 16px außer bei Navigation
- Keine Box-Shadows mit mehr als 4 % Deckkraft
- Keine Emojis, keine Icon-Bibliotheken. Symbolik entsteht über Typografie (Punkte, Kreuze, Pfeile in kursiver Serif)
- Keine schnellen Animationen unter 0,3s

---

## 13. Changelog v2.8 auf v3.0

Alle in der ersten Analyse gefundenen Mängel sind behoben.

### Token-Benennung

| alt | neu | Grund |
|---|---|---|
| `--accent-cyan` | `--accent-primary` | war Sienna, nicht Cyan |
| `--accent-purple` | `--accent-secondary` | war Rost, nicht Violett |
| `--accent-green` | `--accent-live` | Rolle statt Farbe |
| `--accent-orange` | `--accent-warn` | Rolle statt Farbe |
| `--bg-dark` | `--bg-paper` | war die **hellste** Farbe im System |
| `--bg-card` | `--bg-panel` | wurde auch für Navbar genutzt |
| `--bg-terminal` | `--bg-inverse` | Rolle statt Bauteil |
| `--text-dim` | `--text-muted` | Konvention |
| `--border-glow` | `--border-hairline` | ist kein Glow, sondern eine Haarlinie |
| `--term-text-*` | `--inverse-text-*` | konsistent mit `--bg-inverse` |
| `.blob-purple` / `.blob-cyan` | `.blob-primary` / `.blob-secondary` | Klassennamen waren zusätzlich vertauscht |

### Behobene Mängel

1. **Hartcodierte Farben.** Neun Vorkommen von `rgba(176, 77, 44, ...)` und `rgba(26, 24, 22, ...)` laufen jetzt über `rgba(var(--accent-primary-rgb), ...)` bzw. das neue `--ink-rgb`. Auch der Partikel-Renderer liest die Farbe zur Laufzeit aus dem Token.
2. **Falsche Hex-Kommentare.** Alle Kommentare stimmen jetzt mit dem tatsächlichen Rendering überein und enthalten zusätzlich den Kontrastwert.
3. **Kontrast.** `--text-muted` von 45 % auf 38 % Helligkeit, `--accent-primary` von 43 % auf 40 %, `--accent-live` auf `127 26% 33%`, `--accent-warn` auf `28 62% 36%`, `--inverse-text-muted` von `#7A756C` auf `#9A958C`. Alles ab jetzt AA-konform.
4. **Media-Query-Chaos.** Drei überlappende `768px`-Blöcke mit rund 40 `!important` zu einem Block zusammengeführt, alle `!important` entfernt. Der `580px`-Block stand vor dem `768px`-Block und wurde dadurch teilweise überschrieben, jetzt korrekt sortiert. Eine tote Regel (`grid-column: span 12` in einem zweispaltigen Raster) entfernt.
5. **`prefers-reduced-motion`.** Vollständiger Block ergänzt. Partikel und Blobs werden ausgeblendet, Reveals auf sichtbar gesetzt (sonst bliebe die Seite leer), Hover-Verschiebungen deaktiviert.
6. **Fokus-Sichtbarkeit.** `:focus-visible` mit 2px Sienna-Outline und 3px Offset ergänzt. Vorher war Tastaturnavigation praktisch unsichtbar.
7. **Performance.** Unter 768px entfallen die beiden dekorativen `blur(140px)`-Blobs. Das Partikelfeld bleibt bewusst aktiv, siehe unten.
8. **Dauerlaufender Intervall.** Der Konsolen-Ticker hängt jetzt an einem IntersectionObserver und pausiert zusätzlich bei Tab-Wechsel über `visibilitychange`.
9. **Doppelte Touch-Handler.** Es waren zwei konkurrierende Handler-Sätze auf denselben Events registriert. Beide implementierten dieselbe Funktion, der zuletzt registrierte gewann und rechnete mit `clientX + window.scrollX`. Da das Canvas `position: fixed` ist und in Viewport-Koordinaten arbeitet, lag der Abstoßungspunkt nach dem Scrollen um die Scrollhöhe unter dem Finger. Der doppelte Satz ist entfernt, der korrekt rechnende bleibt.
10. **Skalen tokenisiert.** Typo-Skala (`--step-*`), Abstände (`--space-*`), Radien (`--radius-*`) und Easing (`--ease-brand`) sind jetzt Tokens. Die Typo-Skala ist auf Headlines, Lead-Absätze und Fließtext angewandt, die Radien vollständig.

### Bewusst nicht geändert

- **Dark Mode.** Technisch trivial (zweiter `:root`-Block), praktisch nicht: Papierkorn mit `multiply`, Blobs mit `multiply` und die dunklen Konsolenpanels müssten alle drei neu gedacht werden. Das ist ein eigenes Projekt, kein Bugfix.
- **Vollständiger Abstands-Refactor.** Die `--space-*`-Tokens sind definiert und im neuen CSS durchgängig genutzt, in der bestehenden `salvatore.html` aber nur in den überarbeiteten Blöcken. Ein flächiger Austausch aller Pixelwerte wäre ein hohes Regressionsrisiko bei geringem Nutzen.
- **Der Sienna-Ton.** 3 Prozentpunkte dunkler. Falls dir der Unterschied auffällt und stört: eine Zeile zurück auf `15 60% 43%`, dann fallen allerdings 9 bis 11px große Labels wieder unter AA.

---

## 14. Prüfliste vor dem Livegang

- [ ] Kontrast mit einem Checker gegen beide Flächen geprüft
- [ ] Seite mit aktiviertem "Bewegung reduzieren" geöffnet, Inhalt sichtbar
- [ ] Mit Tab durchnavigiert, Fokus jederzeit erkennbar
- [ ] Auf einem echten Mittelklasse-Android geöffnet, kein Ruckeln beim Scrollen
- [ ] Keine hartcodierten Farbwerte im Diff
- [ ] Kein `!important` außerhalb des Reduced-Motion-Blocks
- [ ] Alle Kennzahlen haben eine Quellenzeile
- [ ] Pro Headline maximal ein kursives Akzentwort
